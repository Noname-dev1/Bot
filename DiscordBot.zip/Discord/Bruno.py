import io
import os
import aiohttp
import discord
from discord.ext import commands
import json
import random
import asyncio
import spotipy
from spotipy.oauth2 import SpotifyOAuth

# Your Spotify credentials
SPOTIPY_CLIENT_ID = '2a7320a1e8eb46c796cef44f36356cd7'
SPOTIPY_CLIENT_SECRET = 'e8edbad6476b468fa5eb9fc6053590d0'
SPOTIPY_REDIRECT_URI = 'http://localhost:8888/callback'

# Spotify authentication
sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
    client_id=SPOTIPY_CLIENT_ID,
    client_secret=SPOTIPY_CLIENT_SECRET,
    redirect_uri=SPOTIPY_REDIRECT_URI,
    scope='playlist-read-private'
))

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)
REDDIT_API_URL = 'https://www.reddit.com/r/memes/random/.json'

# Replace these with your actual channel IDs
WELCOME_CHANNEL_ID = 1134033569631711303  # Replace with your actual welcome channel ID
RANK_UPDATE_CHANNEL_ID = 1134039395033419776  # Replace with your actual rank update channel ID

# Files for storing data
USER_DATA_FILE = 'users.json'
QUOTES_FILE = 'quotes.json'

class QuoteManager:
    def __init__(self):
        self.quotes = self.load_quotes()
        self.last_quote_index = -1

    def load_quotes(self):
        if os.path.exists(QUOTES_FILE):
            with open(QUOTES_FILE, 'r') as f:
                return json.load(f)
        return []

    def save_quotes(self):
        with open(QUOTES_FILE, 'w') as f:
            json.dump(self.quotes, f, indent=4)

    def get_next_quote(self):
        if not self.quotes:
            return None

        available_indices = [i for i in range(len(self.quotes)) if i != self.last_quote_index]
        if not available_indices:
            return None

        next_index = random.choice(available_indices)
        self.last_quote_index = next_index
        return self.quotes[next_index]

    def reload_quotes(self):
        self.quotes = self.load_quotes()
        self.last_quote_index = -1

quote_manager = QuoteManager()

def load_user_data():
    if os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, 'r') as f:
            return json.load(f)
    return {}

def load_user_data():
    if os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_user_data(user_data):
    with open(USER_DATA_FILE, 'w') as f:
        json.dump(user_data, f, indent=4)

user_data = load_user_data()

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}')

@bot.command(name='meme')
async def meme(ctx):
    """Fetch and send a random meme image from Reddit."""
    retry_count = 0
    max_retries = 3

    while retry_count < max_retries:
        async with aiohttp.ClientSession() as session:
            async with session.get(REDDIT_API_URL, headers={'User-Agent': 'discord-bot'}) as response:
                if response.status == 200:
                    json_data = await response.json()
                    meme_url = json_data[0]['data']['children'][0]['data']['url']
                    
                    if meme_url:
                        async with session.get(meme_url) as img_response:
                            if img_response.status == 200:
                                image_data = io.BytesIO(await img_response.read())
                                await ctx.send(file=discord.File(image_data, 'meme.jpg'))
                                break
                            else:
                                await ctx.send(f"Failed to fetch meme image. Status code: {img_response.status}")
                                break
                elif response.status == 429:
                    retry_count += 1
                    wait_time = int(response.headers.get('Retry-After', 1))
                    await asyncio.sleep(wait_time)  # Wait before retrying
                else:
                    await ctx.send(f"Failed to fetch meme data. Status code: {response.status}")
                    break
    else:
        await ctx.send("Failed to fetch meme after several attempts.")

@bot.event
async def on_message(message):
    if message.author.bot:
        return

    user_id = str(message.author.id)
    guild_id = str(message.guild.id)
    channel_id = str(message.channel.id)
    
    # Initialize user data for the guild if it doesn't exist
    if guild_id not in user_data:
        user_data[guild_id] = {}

    if user_id not in user_data[guild_id]:
        user_data[guild_id][user_id] = {"messages": {}, "points": 0}

    # Ensure "messages" key exists
    if "messages" not in user_data[guild_id][user_id]:
        user_data[guild_id][user_id]["messages"] = {}

    # Initialize message count for the channel if it doesn't exist
    if channel_id not in user_data[guild_id][user_id]["messages"]:
        user_data[guild_id][user_id]["messages"][channel_id] = 0

    # Increment message count
    user_data[guild_id][user_id]["messages"][channel_id] += 1

    # Example level-up condition: every 10 messages
    if user_data[guild_id][user_id]["messages"][channel_id] % 10 == 0:
        old_points = user_data[guild_id][user_id]["points"]
        user_data[guild_id][user_id]["points"] += 10
        new_points = user_data[guild_id][user_id]["points"]

        # Debug: Print points update
        print(f"{message.author.name} has been awarded points. Old Points: {old_points}, New Points: {new_points}")
        
        save_user_data(user_data)  # Save the updated user data

    await bot.process_commands(message)

@bot.command(name='rank')
async def rank(ctx, user: discord.User = None):
    """Show the rank of a specified user or the command invoker if no user is specified."""
    user = user or ctx.author
    user_id = str(user.id)
    guild_id = str(ctx.guild.id)

    if guild_id not in user_data:
        await ctx.send(f'{user.name}, there is no data available for this server.')
        return

    if user_id not in user_data[guild_id]:
        await ctx.send(f'{user.name}, you have not sent any messages in this server yet.')
        return

    user_data_guild_user = user_data[guild_id][user_id]

    # Ensure 'points' key exists
    if 'points' not in user_data_guild_user:
        user_data_guild_user['points'] = 0

    total_points = user_data_guild_user['points']

    # Sort users by total points
    sorted_users = sorted(
        (
            (uid, data.get("points", 0))
            for uid, data in user_data[guild_id].items()
        ),
        key=lambda x: x[1], reverse=True
    )

    # Find the user's rank
    user_rank = next((index + 1 for index, (uid, _) in enumerate(sorted_users) if uid == user_id), None)

    if user_rank:
        await ctx.send(f'**{user.name}**, your current rank is **{user_rank}**!')
    else:
        await ctx.send(f'**{user.name}**, have no points yet.')

@bot.command(name='ranking')
async def ranking(ctx):
    """Show the top 10 users based on their points in the whole server."""
    guild_id = str(ctx.guild.id)

    if guild_id not in user_data:
        await ctx.send("No user data available.")
        return

    # Sort users by total points
    sorted_users = sorted(
        (
            (user_id, data["points"])
            for user_id, data in user_data[guild_id].items()
        ),
        key=lambda x: x[1], reverse=True
    )

    top_users = sorted_users[:10]

    if top_users:
        ranking_message = "**Top 10 Users by Points in This Server:**\n"
        for rank, (user_id, points) in enumerate(top_users, start=1):
            user = bot.get_user(int(user_id))
            if user:
                ranking_message += f"{rank}. {user.name} - **{points}** points\n"
            else:
                ranking_message += f"{rank}. User ID {user_id} - **{points}** points\n"
        await ctx.send(ranking_message)
    else:
        await ctx.send("No user data available.")

@bot.command(name='commands')
async def commands_list(ctx):
    commands = """
    **Available Commands:**
    - `!meme`: Sends a random meme image.
    - `!play <url>`: Plays audio from the provided URL in your voice channel.
    - `!stop`: Stops the audio playback and disconnects from the voice channel.
    - `!rank [user]`: Shows the rank of the specified user (or yourself if no user is mentioned).
    - `!ranking`: Lists the top 10 users by points.
    - `!addquote <author> <quote>`: Adds a new quote with the author to the list.
    - `!quote`: Sends a random quote from the list.
    - `!removequote <quote>`: Removes a quote from the list.
    """
    await ctx.send(commands)

@bot.command(name='addquote')
async def add_quote(ctx, author: str, *, quote: str):
    """Add a quote with the author to the list."""
    quote_manager.quotes.append({"author": author, "quote": quote})
    quote_manager.save_quotes()
    await ctx.send(f'**Quote added:**\n*"{quote}"* - **{author}**')

@bot.command(name='quote')
async def quote(ctx):
    """Send a quote in a specific order."""
    quote_data = quote_manager.get_next_quote()
    
    if quote_data:
        # Ensure 'quote' and 'author' keys exist in the quote_data dictionary
        quote_text = quote_data.get("quote", "No quote available.")
        author_name = quote_data.get("author", "Unknown author")
        
        # Format the message with the desired style
        formatted_message = f'**{quote_text}** - **{author_name}**'
        await ctx.send(formatted_message)
    else:
        await ctx.send("No quotes available.")


@bot.command(name='reloadquotes')
async def reload_quotes(ctx):
    """Reload the quotes from file."""
    quote_manager.reload_quotes()
    await ctx.send("Quotes reloaded.")

@bot.command(name='removequote')
async def remove_quote(ctx, *, quote: str):
    """Remove a specific quote from the list."""
    original_count = len(quote_manager.quotes)
    quote_manager.quotes = [q for q in quote_manager.quotes if q["quote"] != quote]
    
    if len(quote_manager.quotes) == original_count:
        await ctx.send(f'**Quote not found:**\n*"{quote}"*')
    else:
        quote_manager.save_quotes()
        await ctx.send(f'**Quote removed:**\n*"{quote}"*')

    # Debug: print updated list of quotes
    print("Updated quotes:", quote_manager.quotes)

bot.run('MTI2Mzc5MDY3MDkwNTIxMjk2OA.GTRGN5.mJ3Q6ZHS5fRlqZJVSonI6C5fC0RxUi2rIfSjU4')



#SPOTIPY_CLIENT_ID = '2a7320a1e8eb46c796cef44f36356cd7'
#SPOTIPY_CLIENT_SECRET = 'e8edbad6476b468fa5eb9fc6053590d0'
#SPOTIPY_REDIRECT_URI = 'http://localhost:8888/callback'

#WELCOME_CHANNEL_ID = 1134033569631711303  # Replace with your actual welcome channel ID
#RANK_UPDATE_CHANNEL_ID = 1134039395033419776  # Replace with your actual rank update channel ID
